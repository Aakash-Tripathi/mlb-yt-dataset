# mlb-yt-dataset

This repo is a fork of 

Please check out the original paper for more details on the dataset \[[arXiv](https://arxiv.org/abs/1804.03247)\].
